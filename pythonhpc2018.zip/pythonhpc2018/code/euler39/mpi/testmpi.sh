#!/bin/bash
#SBATCH --reservation coss-wr_cpu
#SBATCH --account coss-wa
#SBATCH --mem-per-cpu=3G
#SBATCH --time=0-00:10
#SBATCH --ntasks=4
time mpirun -np 4 python euler39_mpi.py
