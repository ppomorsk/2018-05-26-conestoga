#!/bin/bash
#SBATCH --reservation coss-wr_cpu
#SBATCH --account coss-wa
#SBATCH --mem-per-cpu=3G
#SBATCH --time=0-00:10
#SBATCH --cpus-per-task=1
time python euler39_multiprocess.py
