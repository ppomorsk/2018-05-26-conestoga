# for a given integer p
# find all integer combinations of a b c for which
# a*a+b*b=c*c
# a+b+c=p 
# where a<b<c

def find_num_solutions(p):

# find number of solutions n
# as nothing written, setting to -99 for now to ensure asserts all fail
    n=-99
    return n

