#!/bin/bash
#SBATCH --reservation coss-wr_cpu
#SBATCH --account coss-wa
#SBATCH --mem-per-cpu=3G
#SBATCH --time=0-00:10
#SBATCH --cpus-per-task=16
time python main86.py
