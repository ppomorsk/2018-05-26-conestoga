import count
from multiprocessing import Pool

p= Pool (processes=16)

y=range(400,2000)
results = p.map(count.countm,y)

print results

for i in range(len(y)):
    if(results[i]>1000000):
        print y[i],results[i]
        break

