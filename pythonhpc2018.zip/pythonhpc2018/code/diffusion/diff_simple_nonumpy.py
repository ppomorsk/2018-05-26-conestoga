import math
kappa=0.1

n=100000
dx=1.0
niters=500

x=n*[0.0,]
u=n*[0.0,]
udt=n*[0.0,]

# initialize
for i in xrange(len(u)):
    u[i]=math.exp( -(dx*(i-n/2))**2/100000)

# iterate over time steps
for i in xrange(niters):

# compute value after evolving over single time step
    for i in xrange(1,len(u)-1):
        udt[i]=u[i]+kappa*(u[i+1]+u[i-1]-2.0*u[i])

# update value of u
    for i in xrange(len(u)):
        u[i]=udt[i]



